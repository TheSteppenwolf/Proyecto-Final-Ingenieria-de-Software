﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterMind.Classes
{
    internal class Mastermind
    {
        #region Variables

        // Definición del tablero
        int[][] tablero = new int[10][];

        // Definición de los colores
        // [0]->Blanco, [1]->Rojo, [2]->Amarillo, [3]->Morado, [4]->Verde, [5]->Negro, [6]->Anaranjado, [7]->Rosado, [8]->Azul
        //                      [0]         [1]       [2]        [3]        [4]        [5]       [6]         [7]       [8]
        string[] colores = { "#FFFFFF", "#FF0000", "#FFA500", "#800080", "#9ACD32", "#000000", "#FF7F50", "#FF00FF", "#000080" };

        // Definición del código secreto
        int[] secret = new int[4];        

        // Define un código para el tipo de nivel
        // 0 -> No Definido | 1 -> Fácil | 2 -> Medio | 3 -> Díficil
        int id_nivel = 0;

        #endregion

        public Mastermind(int nivel = 0)
        {
            // Define el nivel
            id_nivel = nivel;
            // Inivializa el tablero
            InitTablero();
            // Inicializa el código secreto
            InitSecret();
        }

        #region Métodos

        // Inicializa el tablero con valores iniciales.
        protected void InitTablero()
        {
            for (int i = 0; i < 10; i++) tablero[i] = new int[4];
        }

        // Inicializa un código secreto
        public void InitSecret()
        {
            secret = new int[4];
            int max_secret;

            // Código secreto para el nivel fácil
            if (id_nivel == 1)
            {
                // Máximo de opciones de color
                max_secret = 4;
                Random rand = new Random();
                // Creación del código secreto
                for (int col = 0; col < 4; col++)
                {
                    var temp_color = rand.Next(1, max_secret + 1);
                    // Se verifica que no se repitan los colores
                    while (IsInArray(secret, temp_color)) temp_color = rand.Next(1, max_secret + 1);
                    secret[col] = temp_color;
                }
            }
            // Código para el nivel medio
            else if (id_nivel == 2)
            {
                // Máximo de opciones de color
                max_secret = 8;
                Random rand = new Random();
                // Creación del código secreto
                for (int col = 0; col < 4; col++)
                {
                    var temp_color = rand.Next(1, max_secret+1);
                    // Se verifica que no se repitan los colores
                    while (IsInArray(secret, temp_color)) temp_color = rand.Next(1, max_secret + 1);
                    secret[col] = temp_color;
                }
            }
            // Código para el nivel díficil
            else if (id_nivel == 3)
            {
                // Máximo de opciones de color
                max_secret = 8;
                Random rand = new Random();
                // Creación del código secreto sin importar que se repitan los colores
                for (int col = 0; col < 4; col++)
                {
                    secret[col] = rand.Next(1, max_secret);
                }
            }
        }

        // Verifica si un item se encuentra dentro del código secreto
        private bool IsInArray(int[] temp_array, int item)
        {
            foreach (var iter in temp_array) if (iter == item) return true;
            return false;
        }

        // Prueba una combinación
        public int[] TryCombination(string[] combination)
        {
            // Definición aciertos y tipo de acierto
            // 0 -> No hubo acierto
            // 1 -> Acierto en la posición incorrecta
            // 2 -> Acierto en la posición correcta
            int[] hits = new int[4];
            // Contador
            int hit_count = 0;

            // Descubrir aciertos en la posición correcta
            for (int i = 0; i < combination.Length; i++)
            {
                if (colores[secret[i]] == combination[i])
                {
                    hits[hit_count++] = 2;
                }
            }
            // Descubrir aciertos en la posición incorrecta
            for (int i = 0; i < combination.Length; i++)
            {
                for (int j = 0; j < secret.Length; j++)
                {
                    if (colores[secret[j]] == combination[i] & !(colores[secret[i]] == combination[i]))
                    {
                        hits[hit_count++] = 1;
                    }
                }
            }
            // Devuelve los aciertos
            return hits;
        }        

        #endregion

        #region Getters

        public string[] GetSecret()
        {
            string[] temp = new string[4];
            for(int i = 0; i < secret.Length; i++)
            {
                temp[i] = colores[secret[i]];
            }
            return temp;
        }

        public int GetIdLevel()
        {
            return id_nivel;
        }

        #endregion
    }
}
