﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MasterMind.Classes;
using System.Threading;
using System.IO;

namespace MasterMind.Pages
{
    public class ColoresDataMedio : ObservableCollection<SolidColorBrush>
    {
        //Donde se almacenan los colores que se van a utilizar 
        public ColoresDataMedio() : base()
        {
            Add(new SolidColorBrush(Colors.Red));
            Add(new SolidColorBrush(Colors.Orange));
            Add(new SolidColorBrush(Colors.Purple));
            Add(new SolidColorBrush(Colors.YellowGreen));
            Add(new SolidColorBrush(Colors.Black));
            Add(new SolidColorBrush(Colors.Coral));
            Add(new SolidColorBrush(Colors.Fuchsia));
            Add(new SolidColorBrush(Colors.Navy));
        }
    }
    /// <summary>
    /// Interaction logic for Page2_m.xaml
    /// </summary>
    public partial class Page2_m : Page
    {
        #region Variables

        // Inicializamos el juego para usarse.
        Mastermind game;
        // Permite verificar en que intento se encuentra el usuario
        int count_fila;
        // Variable del puntaje
        int score = 10000;

        #endregion

        public Page2_m()
        {
            InitializeComponent();
            // Crea el juego
            game = new Mastermind(2);
            // Inicializa los intentos
            count_fila = 0;
            // Inicializa la jugabilidad
            InicializarFilas();
            // Inicializa los puntajes
            InicializarPuntaje();
            // Notifica datos del modo de juego
            var thread = new Thread(() => { NotifyGameSettings(); });
            thread.Start();
        }

        #region GUI

        //evento de drag and drop
        private void Ellipse_MouseMove(object sender, MouseEventArgs e)
        {
            if (sender is Ellipse ellipse && e.LeftButton == MouseButtonState.Pressed)
            {
                DragDrop.DoDragDrop(ellipse, ellipse.Fill.ToString(), DragDropEffects.Copy);
            }
        }

        // Pinta un circulo con el color deseado
        private void Border_Drop(object sender, DragEventArgs e)
        {
            if (sender is Border border)
            {
                if (e.Data.GetDataPresent(DataFormats.StringFormat))
                {
                    string stringFromDrop = (string)e.Data.GetData(DataFormats.StringFormat);
                    BrushConverter convertir = new BrushConverter();
                    if (convertir.IsValid(stringFromDrop))
                    {
                        Brush pincel = (Brush)convertir.ConvertFromString(stringFromDrop);
                        // Trae todos los colores utilizados en la fila actual
                        string[] combination = GetCombination();
                        // Establece el nuevo color del círculo
                        border.Background = pincel;
                        // Evalua si el color ya fue utilizado en la creación del código
                        for (int i = 0; i < combination.Length; i++)
                        {
                            if (combination[i] == border.Background.ToString())
                            {
                                // Si lo fue elimina la anterior posición del color y la coloca en la nueva                                
                                ChangePosition(i);
                            }
                        }
                    }
                }
            }
        }

        // Vuelta al menú de selección de niveles
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new SelectLevel());
        }

        // Reinicia el nivel
        private void reboot_btn_Click(object sender, RoutedEventArgs e)
        {
            Reboot();
        }

        // Permite visualizar las instrucciones del juego
        private void instrucciones_btn_Click(object sender, RoutedEventArgs e)
        {
            NotifyRules();
        }

        // Confirmación de combinación
        private void confirmar_btn_Click(object sender, RoutedEventArgs e)
        {
            // Tomamos la combinación que se esta probando al momento.
            string[] combination = GetCombination();
            // Transformamos los colores a hexadecimal
            string[] combination_colors = GetCombinationHexColors(combination);
            // Verificamos si la combinación no tiene datos
            if (!CheckEmpty(combination_colors))
            {
                // Verficamos que todos los colores han sido utilizados y no se han dejado espacios en blanco
                if (!CheckOneEmpty(combination_colors))
                {
                    // Probamos la combinación
                    var hits = game.TryCombination(combination_colors);
                    // Configuramos los aciertos dados y los mostramos al usuario            
                    SetHits(hits);
                    // Incrementamos el contador del intento
                    count_fila++;
                    // Verificar si gano el juego el jugador
                    if (PlayerWon(hits))
                    {
                        if (CheckNewMaxScore())
                        {
                            NotifyMaxScore(Int32.Parse(puntaje_actual.Text));
                            SetMaxScore();
                        }
                        NotifyWon(Int32.Parse(puntaje_actual.Text));
                    }

                    // Actualiza el score del jugador
                    score = score - 1000;
                    puntaje_actual.Text = score.ToString();

                    // Verifica si perdio el juego el jugador
                    if (PlayerLost() & !PlayerWon(hits))
                    {
                        NotifyLost();
                    }
                    // Actualiza las filas que pueden ser modificadas
                    if (count_fila < 10) InicializarFilas();
                }
                else
                {
                    NotifyOneEmpty();
                }
            }
            else
            {
                NotifyEmpty();
            }
        }

        #endregion

        #region Métodos críticos

        // Verifica si el jugador gano
        private bool PlayerWon(int[] hits)
        {
            foreach (var iter in hits) if (iter != 2) return false;
            return true;
        }

        // Verifica si el jugador perdio
        private bool PlayerLost()
        {
            if (count_fila > 9) return true;
            return false;
        }

        // Reinicia el nivel
        private void Reboot()
        {
            // Establece un nuevo código secreto
            if (count_fila > 0) game.InitSecret();
            // Reestablece los intentos
            count_fila = 0;
            // Reestablece el puntaje actual
            score = 10000;
            // Inicializa la disponibilidad de las filas
            InicializarFilas();
            // Reinicia todos los datos del juego actual
            ReiniciarFilas();
        }

        // Hace que una posición  se inicialice
        private void ChangePosition(int position)
        {
            switch (count_fila)
            {
                case (0):
                    if (position == 0) C0_F9.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F9.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F9.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F9.Background = new SolidColorBrush(Colors.White);
                    break;
                case (1):
                    if (position == 0) C0_F8.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F8.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F8.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F8.Background = new SolidColorBrush(Colors.White);
                    break;
                case (2):
                    if (position == 0) C0_F7.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F7.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F7.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F7.Background = new SolidColorBrush(Colors.White);
                    break;
                case (3):
                    if (position == 0) C0_F6.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F6.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F6.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F6.Background = new SolidColorBrush(Colors.White);
                    break;
                case (4):
                    if (position == 0) C0_F5.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F5.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F5.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F5.Background = new SolidColorBrush(Colors.White);
                    break;
                case (5):
                    if (position == 0) C0_F4.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F4.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F4.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F4.Background = new SolidColorBrush(Colors.White);
                    break;
                case (6):
                    if (position == 0) C0_F3.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F3.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F3.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F3.Background = new SolidColorBrush(Colors.White);
                    break;
                case (7):
                    if (position == 0) C0_F2.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F2.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F2.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F2.Background = new SolidColorBrush(Colors.White);
                    break;
                case (8):
                    if (position == 0) C0_F1.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F1.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F1.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F1.Background = new SolidColorBrush(Colors.White);
                    break;
                case (9):
                    if (position == 0) C0_F0.Background = new SolidColorBrush(Colors.White);
                    else if (position == 1) C1_F0.Background = new SolidColorBrush(Colors.White);
                    else if (position == 2) C2_F0.Background = new SolidColorBrush(Colors.White);
                    else if (position == 3) C3_F0.Background = new SolidColorBrush(Colors.White);
                    break;
            }
        }

        // Verifica si la combinación esta vacía
        private bool CheckEmpty(string[] colors)
        {
            foreach (var iter in colors) if (iter != "#FFFFFF") return false;
            return true;
        }

        // Verifica que no existan items en blanco para las combinaciones de los intentos
        private bool CheckOneEmpty(string[] colors)
        {
            foreach (var iter in colors) if (iter == "#FFFFFF") return true;
            return false;
        }

        // Establece el puntaje máximo
        private void SetMaxScore()
        {
            // Identifica que nivel se esta jugando
            var id = game.GetIdLevel();
            // Variables para modificar el archivo de puntajes
            string filename = "scores.txt";
            string[] scores = new string[3];
            int count = 0;

            // Lee los datos y guarda en scores
            var linesRead = File.ReadLines("scores.txt");
            foreach (var iter in linesRead)
            {
                scores[count++] = iter;
            }

            // Borra el archivo
            if (File.Exists(filename)) File.Delete(filename);

            // Establece la nueva información
            if (id == 1)
            {
                scores[0] = score.ToString();
            }
            else if (id == 2)
            {
                scores[1] = score.ToString();
            }
            else if (id == 3)
            {
                scores[2] = score.ToString();
            }

            // Guarda la nueva información
            using (FileStream fs = File.Create(filename))
            {
                Byte[] score_1 = new UTF8Encoding(true).GetBytes(scores[0] + "\n");
                Byte[] score_2 = new UTF8Encoding(true).GetBytes(scores[1] + "\n");
                Byte[] score_3 = new UTF8Encoding(true).GetBytes(scores[2] + "\n");
                fs.Write(score_1, 0, score_1.Length);
                fs.Write(score_2, 0, score_2.Length);
                fs.Write(score_3, 0, score_3.Length);
            }
        }

        // Evalua si se logro un nuevo marcador
        private bool CheckNewMaxScore()
        {
            if (score > Int32.Parse(puntaje_maximo.Text)) return true;
            return false;
        }

        #endregion

        #region Getters

        // Devuelve la combinación que se esta probando
        private string[] GetCombination()
        {
            string[] temp = new string[4];
            // El número del case + 1 indica la fila que se esta probando.
            switch (count_fila)
            {
                case (0):
                    temp[0] = C0_F9.Background.ToString();
                    temp[1] = C1_F9.Background.ToString();
                    temp[2] = C2_F9.Background.ToString();
                    temp[3] = C3_F9.Background.ToString();
                    break;
                case (1):
                    temp[0] = C0_F8.Background.ToString();
                    temp[1] = C1_F8.Background.ToString();
                    temp[2] = C2_F8.Background.ToString();
                    temp[3] = C3_F8.Background.ToString();
                    break;
                case (2):
                    temp[0] = C0_F7.Background.ToString();
                    temp[1] = C1_F7.Background.ToString();
                    temp[2] = C2_F7.Background.ToString();
                    temp[3] = C3_F7.Background.ToString();
                    break;
                case (3):
                    temp[0] = C0_F6.Background.ToString();
                    temp[1] = C1_F6.Background.ToString();
                    temp[2] = C2_F6.Background.ToString();
                    temp[3] = C3_F6.Background.ToString();
                    break;
                case (4):
                    temp[0] = C0_F5.Background.ToString();
                    temp[1] = C1_F5.Background.ToString();
                    temp[2] = C2_F5.Background.ToString();
                    temp[3] = C3_F5.Background.ToString();
                    break;
                case (5):
                    temp[0] = C0_F4.Background.ToString();
                    temp[1] = C1_F4.Background.ToString();
                    temp[2] = C2_F4.Background.ToString();
                    temp[3] = C3_F4.Background.ToString();
                    break;
                case (6):
                    temp[0] = C0_F3.Background.ToString();
                    temp[1] = C1_F3.Background.ToString();
                    temp[2] = C2_F3.Background.ToString();
                    temp[3] = C3_F3.Background.ToString();
                    break;
                case (7):
                    temp[0] = C0_F2.Background.ToString();
                    temp[1] = C1_F2.Background.ToString();
                    temp[2] = C2_F2.Background.ToString();
                    temp[3] = C3_F2.Background.ToString();
                    break;
                case (8):
                    temp[0] = C0_F1.Background.ToString();
                    temp[1] = C1_F1.Background.ToString();
                    temp[2] = C2_F1.Background.ToString();
                    temp[3] = C3_F1.Background.ToString();
                    break;
                case (9):
                    temp[0] = C0_F0.Background.ToString();
                    temp[1] = C1_F0.Background.ToString();
                    temp[2] = C2_F0.Background.ToString();
                    temp[3] = C3_F0.Background.ToString();
                    break;
            }
            return temp;
        }

        // Transforma los colores Brush a su equivalente en Hexadecimal
        private string[] GetCombinationHexColors(string[] temp)
        {
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] == "#FFFFFFFF") temp[i] = "#FFFFFF"; // Conversión del blanco                
                else if (temp[i] == "#FFFF0000") temp[i] = "#FF0000"; // Conversión del color rojo
                else if (temp[i] == "#FFFFA500") temp[i] = "#FFA500"; // Conversión del color amarillo
                else if (temp[i] == "#FF800080") temp[i] = "#800080"; // Conversión del color morado
                else if (temp[i] == "#FF9ACD32") temp[i] = "#9ACD32"; // Conversión del color verde
                else if (temp[i] == "#00000000") temp[i] = "#000000"; // Conversión del color negro
                else if (temp[i] == "#FFFF7F50") temp[i] = "#FF7F50"; // Conversión del color anaranjado
                else if (temp[i] == "#FFFF00FF") temp[i] = "#FF00FF"; // Conversión del color rosado
                else if (temp[i] == "#FF000080") temp[i] = "#000080"; // Conversión del color azul
            }
            return temp;
        }

        #endregion

        #region Inicializadores      

        // Permite la visualización de los aciertos dados al usuario
        private void SetHits(int[] hits)
        {
            // Coloca color negro si hay un item en la posición correcta.
            // Coloca color gris si hay un item en la posición incorrecta.
            // Deja en blanco si no existe items acertados.
            switch (count_fila)
            {
                case (0):
                    // Primer circulo
                    if (hits[0] == 2) A1_F10.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F10.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F10.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F10.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F10.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A3_F10.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F10.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F10.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (1):
                    // Primer circulo
                    if (hits[0] == 2) A1_F9.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F9.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F9.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F9.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F9.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F9.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F9.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F9.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (2):
                    // Primer circulo
                    if (hits[0] == 2) A1_F8.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F8.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F8.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F8.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F8.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F8.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F8.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F8.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (3):
                    // Primer circulo
                    if (hits[0] == 2) A1_F7.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F7.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F7.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F7.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F7.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F7.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F7.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F7.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (4):
                    // Primer circulo
                    if (hits[0] == 2) A1_F6.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F6.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F6.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F6.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F6.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F6.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F6.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F6.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (5):
                    // Primer circulo
                    if (hits[0] == 2) A1_F5.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F5.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F5.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F5.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F5.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F5.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F5.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F5.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (6):
                    // Primer circulo
                    if (hits[0] == 2) A1_F4.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F4.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F4.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F4.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F4.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F4.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F4.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F4.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (7):
                    // Primer circulo
                    if (hits[0] == 2) A1_F3.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F3.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F3.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F3.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F3.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F3.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F3.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F3.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (8):
                    // Primer circulo
                    if (hits[0] == 2) A1_F2.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F2.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F2.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F2.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F2.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F2.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F10.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F2.Background = new SolidColorBrush(Colors.Gray);
                    break;
                case (9):
                    // Primer circulo
                    if (hits[0] == 2) A1_F1.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[0] == 1) A1_F1.Background = new SolidColorBrush(Colors.Gray);
                    // Segundo circulo
                    if (hits[1] == 2) A2_F1.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[1] == 1) A2_F1.Background = new SolidColorBrush(Colors.Gray);
                    // Tercer circulo
                    if (hits[2] == 2) A3_F1.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[2] == 1) A3_F1.Background = new SolidColorBrush(Colors.Gray);
                    // Cuarto circulo
                    if (hits[3] == 2) A4_F1.Background = new SolidColorBrush(Colors.Black);
                    else if (hits[3] == 1) A4_F1.Background = new SolidColorBrush(Colors.Gray);
                    break;
            }
        }

        // Inicializa las filas que pueden ser modificadas
        private void InicializarFilas()
        {

            switch (count_fila)
            {
                case 0:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = true;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = true;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = true;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = true;
                    break;
                case 1:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = true;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = true;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = true;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = true;
                    C3_F9.AllowDrop = false;
                    break;
                case 2:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = true;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = true;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = true;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = true;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 3:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = true;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = true;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = true;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = true;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 4:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = true;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = true;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = true;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = true;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 5:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = true;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = true;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = true;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = true;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 6:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = true;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = true;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = true;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = true;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 7:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = true;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = true;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = true;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = true;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;
                case 8:
                    C0_F0.AllowDrop = false;
                    C0_F1.AllowDrop = true;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = false;
                    C1_F1.AllowDrop = true;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = false;
                    C2_F1.AllowDrop = true;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = false;
                    C3_F1.AllowDrop = true;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;

                case 9:
                    C0_F0.AllowDrop = true;
                    C0_F1.AllowDrop = false;
                    C0_F2.AllowDrop = false;
                    C0_F3.AllowDrop = false;
                    C0_F4.AllowDrop = false;
                    C0_F5.AllowDrop = false;
                    C0_F6.AllowDrop = false;
                    C0_F7.AllowDrop = false;
                    C0_F8.AllowDrop = false;
                    C0_F9.AllowDrop = false;

                    C1_F0.AllowDrop = true;
                    C1_F1.AllowDrop = false;
                    C1_F2.AllowDrop = false;
                    C1_F3.AllowDrop = false;
                    C1_F4.AllowDrop = false;
                    C1_F5.AllowDrop = false;
                    C1_F6.AllowDrop = false;
                    C1_F7.AllowDrop = false;
                    C1_F8.AllowDrop = false;
                    C1_F9.AllowDrop = false;

                    C2_F0.AllowDrop = true;
                    C2_F1.AllowDrop = false;
                    C2_F2.AllowDrop = false;
                    C2_F3.AllowDrop = false;
                    C2_F4.AllowDrop = false;
                    C2_F5.AllowDrop = false;
                    C2_F6.AllowDrop = false;
                    C2_F7.AllowDrop = false;
                    C2_F8.AllowDrop = false;
                    C2_F9.AllowDrop = false;

                    C3_F0.AllowDrop = true;
                    C3_F1.AllowDrop = false;
                    C3_F2.AllowDrop = false;
                    C3_F3.AllowDrop = false;
                    C3_F4.AllowDrop = false;
                    C3_F5.AllowDrop = false;
                    C3_F6.AllowDrop = false;
                    C3_F7.AllowDrop = false;
                    C3_F8.AllowDrop = false;
                    C3_F9.AllowDrop = false;
                    break;

            }
        }

        // Reinicia todas las filas a su valor inicial -> en blanco
        private void ReiniciarFilas()
        {
            // Primeras columnas de todas las filas
            C0_F0.Background = new SolidColorBrush(Colors.White);
            C0_F1.Background = new SolidColorBrush(Colors.White);
            C0_F2.Background = new SolidColorBrush(Colors.White);
            C0_F3.Background = new SolidColorBrush(Colors.White);
            C0_F4.Background = new SolidColorBrush(Colors.White);
            C0_F5.Background = new SolidColorBrush(Colors.White);
            C0_F6.Background = new SolidColorBrush(Colors.White);
            C0_F7.Background = new SolidColorBrush(Colors.White);
            C0_F8.Background = new SolidColorBrush(Colors.White);
            C0_F9.Background = new SolidColorBrush(Colors.White);
            // Segundas columnas de todas las filas
            C1_F0.Background = new SolidColorBrush(Colors.White);
            C1_F1.Background = new SolidColorBrush(Colors.White);
            C1_F2.Background = new SolidColorBrush(Colors.White);
            C1_F3.Background = new SolidColorBrush(Colors.White);
            C1_F4.Background = new SolidColorBrush(Colors.White);
            C1_F5.Background = new SolidColorBrush(Colors.White);
            C1_F6.Background = new SolidColorBrush(Colors.White);
            C1_F7.Background = new SolidColorBrush(Colors.White);
            C1_F8.Background = new SolidColorBrush(Colors.White);
            C1_F9.Background = new SolidColorBrush(Colors.White);
            // Terceras columnas de todas las filas
            C2_F0.Background = new SolidColorBrush(Colors.White);
            C2_F1.Background = new SolidColorBrush(Colors.White);
            C2_F2.Background = new SolidColorBrush(Colors.White);
            C2_F3.Background = new SolidColorBrush(Colors.White);
            C2_F4.Background = new SolidColorBrush(Colors.White);
            C2_F5.Background = new SolidColorBrush(Colors.White);
            C2_F6.Background = new SolidColorBrush(Colors.White);
            C2_F7.Background = new SolidColorBrush(Colors.White);
            C2_F8.Background = new SolidColorBrush(Colors.White);
            C2_F9.Background = new SolidColorBrush(Colors.White);
            // Cuartas columnas de todas las filas
            C3_F0.Background = new SolidColorBrush(Colors.White);
            C3_F1.Background = new SolidColorBrush(Colors.White);
            C3_F2.Background = new SolidColorBrush(Colors.White);
            C3_F3.Background = new SolidColorBrush(Colors.White);
            C3_F4.Background = new SolidColorBrush(Colors.White);
            C3_F5.Background = new SolidColorBrush(Colors.White);
            C3_F6.Background = new SolidColorBrush(Colors.White);
            C3_F7.Background = new SolidColorBrush(Colors.White);
            C3_F8.Background = new SolidColorBrush(Colors.White);
            C3_F9.Background = new SolidColorBrush(Colors.White);
            // Acierto 1 de todas las filas
            A1_F1.Background = new SolidColorBrush(Colors.White);
            A1_F2.Background = new SolidColorBrush(Colors.White);
            A1_F3.Background = new SolidColorBrush(Colors.White);
            A1_F4.Background = new SolidColorBrush(Colors.White);
            A1_F5.Background = new SolidColorBrush(Colors.White);
            A1_F6.Background = new SolidColorBrush(Colors.White);
            A1_F7.Background = new SolidColorBrush(Colors.White);
            A1_F8.Background = new SolidColorBrush(Colors.White);
            A1_F9.Background = new SolidColorBrush(Colors.White);
            A1_F10.Background = new SolidColorBrush(Colors.White);
            // Acierto 2 de todas las filas
            A2_F1.Background = new SolidColorBrush(Colors.White);
            A2_F2.Background = new SolidColorBrush(Colors.White);
            A2_F3.Background = new SolidColorBrush(Colors.White);
            A2_F4.Background = new SolidColorBrush(Colors.White);
            A2_F5.Background = new SolidColorBrush(Colors.White);
            A2_F6.Background = new SolidColorBrush(Colors.White);
            A2_F7.Background = new SolidColorBrush(Colors.White);
            A2_F8.Background = new SolidColorBrush(Colors.White);
            A2_F9.Background = new SolidColorBrush(Colors.White);
            A2_F10.Background = new SolidColorBrush(Colors.White);
            // Acierto 3 de todas las filas
            A3_F1.Background = new SolidColorBrush(Colors.White);
            A3_F2.Background = new SolidColorBrush(Colors.White);
            A3_F3.Background = new SolidColorBrush(Colors.White);
            A3_F4.Background = new SolidColorBrush(Colors.White);
            A3_F5.Background = new SolidColorBrush(Colors.White);
            A3_F6.Background = new SolidColorBrush(Colors.White);
            A3_F7.Background = new SolidColorBrush(Colors.White);
            A3_F8.Background = new SolidColorBrush(Colors.White);
            A3_F9.Background = new SolidColorBrush(Colors.White);
            A3_F10.Background = new SolidColorBrush(Colors.White);
            // Acierto 4 de todas las filas
            A4_F1.Background = new SolidColorBrush(Colors.White);
            A4_F2.Background = new SolidColorBrush(Colors.White);
            A4_F3.Background = new SolidColorBrush(Colors.White);
            A4_F4.Background = new SolidColorBrush(Colors.White);
            A4_F5.Background = new SolidColorBrush(Colors.White);
            A4_F6.Background = new SolidColorBrush(Colors.White);
            A4_F7.Background = new SolidColorBrush(Colors.White);
            A4_F8.Background = new SolidColorBrush(Colors.White);
            A4_F9.Background = new SolidColorBrush(Colors.White);
            A4_F10.Background = new SolidColorBrush(Colors.White);
        }


        // Inicializa el puntaje inicial
        private void InicializarPuntaje()
        {
            puntaje_actual.Text = score.ToString();
            puntaje_maximo.Text = InitMaxScore();
        }

        // Trae puntajes máximos existentes
        private string InitMaxScore()
        {
            string curFile = @"scores.txt";
            // Verifica si existen datos guardados
            if (File.Exists(curFile))
            {
                string[] scores = new string[3];
                int count = 0;
                var linesRead = File.ReadLines("scores.txt");
                foreach (var iter in linesRead)
                {
                    scores[count++] = iter;
                }
                if (game.GetIdLevel() == 1)
                {
                    return scores[0];
                }
                else if (game.GetIdLevel() == 2)
                {
                    return scores[1];
                }
                else if (game.GetIdLevel() == 3)
                {
                    return scores[2];
                }
            }
            else
            {
                using (FileStream fs = File.Create(curFile))
                {
                    Byte[] temp_score = new UTF8Encoding(true).GetBytes("0\n");
                    fs.Write(temp_score, 0, temp_score.Length);
                    fs.Write(temp_score, 0, temp_score.Length);
                    fs.Write(temp_score, 0, temp_score.Length);
                }
            }
            return "0";
        }

        #endregion

        #region Notificaciones

        // Muestra un mensaje de que el jugador gano
        private void NotifyWon(int p_score)
        {
            string message = $"¡Felicitaciones!\n\n ¡Has pasado el nivel! Tú puntaje fue de {p_score}.";
            string caption = "¡Has ganado!";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
            switch (result)
            {
                // Vuelve al menú de niveles
                case MessageBoxResult.OK:
                    NavigationService.Navigate(new SelectLevel());
                    break;
            }
        }

        // Muestra un mensaje de que el jugador perdio
        private void NotifyLost()
        {
            string message = "¡Oh No! No has logrado superar el nivel...\n\n¿Deseas intentar de nuevo?";
            string caption = "¡Perdiste!";
            MessageBoxButton button = MessageBoxButton.YesNo;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
            switch (result)
            {
                // Reinicia el nivel
                case MessageBoxResult.Yes:
                    Reboot();
                    break;

                // Vuelve al menú de niveles
                case MessageBoxResult.No:
                    NavigationService.Navigate(new SelectLevel());
                    break;
            }
        }

        // Muestra las configuraciones del nivel
        private void NotifyGameSettings()
        {
            string message = "¡Bienvenido!\n\nHas seleccionado el nivel de dificultad medio, tienes 8 colores para crear tus combinaciones pero estos no se pueden repetir.";
            string caption = "Nivel: Medio";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
            switch (result)
            {
                // No ocurre nada
                case MessageBoxResult.OK:
                    break;
            }
        }

        // Notifica que un color ha sido repetido
        private void NotifyRepeatedColor()
        {
            string message = "¡Has repetido un color!\n¡Recuerda que en este nivel no esta permitido su repetición!";
            string caption = "Advertencia";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
            switch (result)
            {
                // No sucede nada
                case MessageBoxResult.OK:
                    break;
            }
        }

        // Notifica si la combinación fue ejecutada vacía
        private void NotifyEmpty()
        {
            string message = "Parece que no has colocado ningún tipo de combinación...\n\n¡Coloca alguna antes de probar!";
            string caption = "Advertencia";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
        }

        // Notifica que hay un item en blanco en la combinación
        private void NotifyOneEmpty()
        {
            string message = "Parece que has dejado un espacio en blanco...\n\n¡Ten más cuidado la próxima vez!";
            string caption = "Advertencia";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
        }

        // Notifica que se logro un nuevo record
        private void NotifyMaxScore(int p_score)
        {
            string message = $"¡Has logrado un nuevo record!\n\nObtuviste un puntaje de: {p_score}";
            string caption = "Felicitaciones";
            MessageBoxButton button = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, button);
        }

        // Notifica las instrucciones del juego
        private void NotifyRules()
        {
            string message = "¡Recuerda!\n\nCada vez que se empieza una partida, el juego creará un nuevo código secreto que lo debes decifrar en un máximo de 10 intentos que le brindaràn de pistas para resolver el código." +
                "\n\n************************************************************************\n\n" +
                "Sobre el juego:\n\nPara poder acertar con mayor facilidad el código secreto ¡podrás guiarte de las pistas que el juego te proveerá:\n" +
                "1. El color negro significa que tienes un color en la posición correcta!\n" +
                "2. El color gris significa que tienes un color correcta pero en la posición incorrecta!";
            string caption = "Reglas del juego";
            MessageBoxButton buttons = MessageBoxButton.OK;
            MessageBoxResult result = MessageBox.Show(message, caption, buttons);
        }

        #endregion       
    }
}
