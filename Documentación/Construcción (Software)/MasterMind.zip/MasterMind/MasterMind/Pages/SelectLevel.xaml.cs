﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MasterMind.Pages
{
    /// <summary>
    /// Lógica de interacción para SelectLevel.xaml
    /// </summary>
    public partial class SelectLevel : Page
    {
        public SelectLevel()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page1_f());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page2_m());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Page3_d());
            //string message = "¡Proximamente el nivel más complicado que puedas imaginar!";
            //string caption = "Proximamente...";
            //MessageBoxButton button = MessageBoxButton.OK;
            //MessageBoxResult result = MessageBox.Show(message, caption, button);
            //switch (result)
            //{
            //    // Vuelve al menú de niveles
            //    case MessageBoxResult.OK:
            //        NavigationService.Navigate(new SelectLevel());
            //        break;
            //}
        }
    }
}
